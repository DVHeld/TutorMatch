Moodle Local newlocal
===================

This is a template for moodle local plugins
intended to use with moosh for automatic
generation.
